# AUCTION ARENA

**Real 2-Player Online Auction Game**  
Package: `com.auctionarena.live`

## What this is

- Authoritative Node.js + Socket.IO backend
- Beautiful mobile-first web client (works in browser + Android WebView)
- Android Kotlin WebView shell (ready to build APK)
- Custom Player IDs completely separate from Join Codes
- Additive bidding (₹10 + ₹2 = ₹12)
- Server-controlled timer, balances, slots, winners
- Categories: MARVEL / DC / CRICKET / FOOTBALL
- Voice announcements (optional mute)
- Reconnect support

---

## 1. Backend (Required for real multiplayer)

### Local run

```bash
cd server
npm install
node server.js
```

Server starts on `http://localhost:3000`

### Deploy (for two real phones)

Recommended free hosts:

- **Render.com** (Web Service)
- **Railway.app**
- **Fly.io**

Steps for Render:
1. Create new **Web Service**
2. Connect this repo or upload the `server` folder
3. Build command: `npm install`
4. Start command: `node server.js`
5. Add environment if needed (PORT is auto-set)
6. Copy the public URL (e.g. `https://auction-arena-xxxx.onrender.com`)

Also copy the `web` folder content into the server so Express serves the frontend (already configured with `express.static('../web')`).

For simplest deploy: put both `server/` and `web/` in one repo and set root correctly, or merge web into server/public.

---

## 2. Android APK

### Option A – Open in Android Studio (Recommended)

1. Open Android Studio
2. **File → Open** → select the `android/` folder
3. Let Gradle sync
4. In `MainActivity.kt` change `SERVER_URL` to your deployed backend URL
5. Build → Build Bundle(s) / APK(s) → Build APK(s)
6. APK appears in `android/app/build/outputs/apk/debug/app-debug.apk`

### Option B – Command line (if SDK installed)

```bash
cd android
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

### Install on phone

```bash
adb install -r app-debug.apk
```

Or transfer the APK and enable “Install from unknown sources”.

---

## 3. How to play (two phones)

1. Deploy backend + frontend (or run locally + use ngrok / localtunnel for testing)
2. Install APK on both phones (or open the website URL in Chrome)
3. **Phone 1**:
   - Enter custom Player ID (e.g. `PARTH`)
   - Choose Budget / Slots / Category
   - Tap **CREATE GAME**
   - Share the 6-character Join Code
4. **Phone 2**:
   - Enter the Join Code
   - Enter own Player ID (e.g. `ROHAN`)
   - Tap **JOIN GAME**
5. Host taps **START AUCTION**
6. Both phones see the same item, timer, current bid in real time
7. Each phone only shows **its own** bid buttons and balance
8. Bids are additive and server-validated

---

## 4. Project Structure

```
AuctionArena/
├── server/
│   ├── package.json
│   ├── server.js          # Express + Socket.IO
│   ├── rooms.js           # Authoritative game logic
│   └── items.js           # Item database
├── web/
│   ├── index.html
│   ├── styles.css
│   └── app.js             # Client Socket.IO + UI
├── android/
│   ├── settings.gradle
│   ├── build.gradle
│   ├── app/
│   │   ├── build.gradle
│   │   └── src/main/...
└── README.md
```

---

## 5. Test Checklist (as specified)

| Test | Expected |
|------|----------|
| Create room | Join code generated |
| Join from second client | Both see each other in lobby |
| Custom Player IDs | PARTH / ROHAN work, separate from code |
| +₹10 then +₹2 | Total becomes ₹12 |
| +₹10 again | Total becomes ₹22 |
| Winner gets item | Balance decreases, slot increases |
| Opponent cannot change my balance | Server rejects |
| Third player | Rejected (max 2) |
| Disconnect | Shows reconnecting / player disconnected |
| Timer | Server-driven, same on both phones |
| Final result | Synchronized on both devices |

---

## 6. Known Limitations

- Backend is in-memory (rooms disappear if server restarts). For production add Redis or a DB.
- Image URLs are from Unsplash (HTTPS). If one fails, a clean placeholder is shown.
- Text-to-speech uses the device TTS engine (works on most modern Android phones).
- Debug APK is unsigned for distribution beyond testing. For Play Store create a keystore and sign the release build.

---

## 7. Quick local multiplayer test (same Wi-Fi)

1. Run server on a computer: `node server.js`
2. Find computer’s local IP (e.g. `192.168.1.42`)
3. On both phones open `http://192.168.1.42:3000` in Chrome
4. Or set `SERVER_URL` in MainActivity to that IP and rebuild APK

For internet play you **must** deploy the backend to a public URL.

---

Built according to the full specification.
Custom Player ID ≠ Join Code  
Controls isolated per phone  
Bids are additive  
Server is authoritative
