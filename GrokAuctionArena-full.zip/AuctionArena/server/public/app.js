// Auction Arena Client
const SERVER_URL = window.location.origin.includes('localhost') || window.location.origin.includes('127.0.0.1')
  ? 'http://localhost:3000'
  : window.location.origin;

let socket = null;
let myPlayerId = '';
let currentRoom = null;
let isMuted = false;
let selectedCategory = 'MARVEL';
let synth = window.speechSynthesis;

// DOM helpers
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

function showScreen(id) {
  $$('.screen').forEach(s => s.classList.remove('active'));
  $(`#screen-${id}`).classList.add('active');
}

function toast(msg, duration = 2500) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), duration);
}

function speak(text) {
  if (isMuted || !synth) return;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 0.95;
  u.pitch = 0.9;
  u.volume = 0.85;
  synth.speak(u);
}

function validatePlayerId(id) {
  if (!id || id.length < 3 || id.length > 16) return false;
  return /^[A-Za-z0-9_]+$/.test(id);
}

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function connectSocket() {
  if (socket && socket.connected) return;
  socket = io(SERVER_URL, { transports: ['websocket', 'polling'] });

  socket.on('connect', () => {
    console.log('Connected to server');
    $('#reconnect-banner')?.classList.add('hidden');
  });

  socket.on('disconnect', () => {
    $('#reconnect-banner')?.classList.remove('hidden');
  });

  socket.on('player_joined', (room) => {
    currentRoom = room;
    updateLobby(room);
  });

  socket.on('player_reconnected', (room) => {
    currentRoom = room;
    updateLobby(room);
    if (room.status === 'AUCTION') updateGame(room);
  });

  socket.on('player_disconnected', (room) => {
    currentRoom = room;
    updateLobby(room);
    toast('Opponent disconnected');
  });

  socket.on('auction_state', (room) => {
    currentRoom = room;
    updateGame(room);
    handleAuctioneerVoice(room);
  });

  socket.on('auction_tick', (data) => {
    if (currentRoom) {
      currentRoom.auctionTimer = data.auctionTimer;
      currentRoom.auctionState = data.auctionState;
      currentRoom.currentBid = data.currentBid;
      currentRoom.highestBidder = data.highestBidder;
    }
    $('#auction-timer').textContent = formatTime(data.auctionTimer);
    $('#current-bid').textContent = `₹${data.currentBid}`;
    $('#highest-bidder').textContent = data.highestBidder || '—';
  });

  socket.on('bid_update', (data) => {
    if (currentRoom) {
      currentRoom.currentBid = data.currentBid;
      currentRoom.highestBidder = data.highestBidder;
      currentRoom.lastBid = data.lastBid;
      currentRoom.auctionTimer = data.auctionTimer;
      if (data.players) {
        currentRoom.players = data.players;
      }
    }
    $('#current-bid').textContent = `₹${data.currentBid}`;
    $('#highest-bidder').textContent = data.highestBidder || '—';
    if (data.lastBid) {
      $('#last-bid').textContent = `Last: ${data.lastBid.playerId} +₹${data.lastBid.amount}`;
    }
    updateMyPanel();
    $('#auction-timer').textContent = formatTime(data.auctionTimer || 0);
  });

  socket.on('auction_end', (data) => {
    currentRoom = data;
    updateGame(data);
    const soldTo = data.soldTo || 'No one';
    const price = data.soldPrice || 0;
    showAuctioneer(`SOLD! ${soldTo} ₹${price}`);
    speak('Sold!');
  });

  socket.on('game_result', (room) => {
    currentRoom = room;
    showResults(room);
  });
}

function handleAuctioneerVoice(room) {
  const state = room.auctionState;
  if (state === 'INTRO' || state === 'BIDDING') {
    if (room.auctionTimer >= 19 || room.auctionState === 'INTRO') {
      showAuctioneer('BIDDING STARTS!');
      speak('Bidding starts!');
    }
  } else if (state === 'GOING_ONCE') {
    showAuctioneer('GOING ONCE!');
    speak('Going once!');
  } else if (state === 'GOING_TWICE') {
    showAuctioneer('GOING TWICE!');
    speak('Going twice!');
  }
}

function showAuctioneer(text) {
  const banner = $('#auctioneer-banner');
  $('#auctioneer-text').textContent = text;
  banner.classList.remove('hidden');
  setTimeout(() => {
    if (text.includes('SOLD') || text.includes('GOING')) {
      // keep visible longer for sold
    } else {
      banner.classList.add('hidden');
    }
  }, text.includes('SOLD') ? 3500 : 2000);
}

// HOME
$('#setting-budget').addEventListener('change', (e) => {
  $('#custom-budget').style.display = e.target.value === 'custom' ? 'block' : 'none';
});

$$('.cat-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    $$('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    selectedCategory = btn.dataset.cat;
  });
});

$('#btn-mute').addEventListener('click', () => {
  isMuted = !isMuted;
  $('#btn-mute').textContent = isMuted ? '🔇 Sound Off' : '🔊 Sound On';
});

$('#btn-create').addEventListener('click', () => {
  const playerId = $('#home-player-id').value.trim().toUpperCase();
  if (!validatePlayerId(playerId)) {
    toast('Invalid Player ID (3-16 chars, A-Z 0-9 _)');
    return;
  }
  let budget = $('#setting-budget').value;
  if (budget === 'custom') {
    budget = Number($('#custom-budget').value);
    if (!budget || budget < 50) {
      toast('Custom budget must be ≥ ₹50');
      return;
    }
  } else {
    budget = Number(budget);
  }
  const slots = Number($('#setting-slots').value);

  connectSocket();
  myPlayerId = playerId;

  socket.emit('create_room', {
    budget,
    slots,
    category: selectedCategory,
    playerId
  }, (res) => {
    if (res.error) {
      toast(res.error);
      return;
    }
    currentRoom = res.room;
    showLobby(res.room, true);
  });
});

$('#btn-join').addEventListener('click', () => {
  const joinCode = $('#join-code-input').value.trim().toUpperCase();
  const playerId = $('#join-player-id').value.trim().toUpperCase();
  if (!joinCode || joinCode.length < 4) {
    toast('Enter valid Join Code');
    return;
  }
  if (!validatePlayerId(playerId)) {
    toast('Invalid Player ID (3-16 chars, A-Z 0-9 _)');
    return;
  }

  connectSocket();
  myPlayerId = playerId;

  socket.emit('join_room', { joinCode, playerId }, (res) => {
    if (res.error) {
      toast(res.error);
      return;
    }
    currentRoom = res.room;
    showLobby(res.room, false);
  });
});

function showLobby(room, isHost) {
  showScreen('lobby');
  $('#lobby-code').textContent = room.joinCode;
  updateLobby(room);
  $('#btn-start').disabled = !isHost || room.players.length < 2;
  $('#btn-start').style.display = isHost ? 'block' : 'none';
}

function updateLobby(room) {
  const players = room.players || [];
  const p1 = players.find(p => p.isHost) || players[0];
  const p2 = players.find(p => !p.isHost);

  $('#lobby-p1-name').textContent = p1 ? p1.id : '—';
  $('#lobby-p1-status').textContent = p1?.connected ? 'READY' : 'DISCONNECTED';
  $('#lobby-p1-status').className = 'status ' + (p1?.connected ? 'ready' : 'waiting');

  if (p2) {
    $('#lobby-p2-name').textContent = p2.id;
    $('#lobby-p2-status').textContent = p2.connected ? 'READY' : 'DISCONNECTED';
    $('#lobby-p2-status').className = 'status ' + (p2.connected ? 'ready' : 'waiting');
  } else {
    $('#lobby-p2-name').textContent = 'WAITING...';
    $('#lobby-p2-status').textContent = '—';
    $('#lobby-p2-status').className = 'status waiting';
  }

  const isHost = players.find(p => p.id === myPlayerId)?.isHost;
  $('#btn-start').disabled = !isHost || players.length < 2;
  $('#btn-start').style.display = isHost ? 'block' : 'none';
}

$('#btn-copy-code').addEventListener('click', () => {
  const code = $('#lobby-code').textContent;
  navigator.clipboard?.writeText(code).then(() => toast('Code copied!'));
});

$('#btn-start').addEventListener('click', () => {
  socket.emit('start_game', {}, (res) => {
    if (res.error) toast(res.error);
  });
});

$('#btn-leave-lobby').addEventListener('click', () => {
  socket?.emit('leave_room');
  currentRoom = null;
  showScreen('home');
});

// GAME
function updateGame(room) {
  showScreen('game');
  $('#game-code').textContent = room.joinCode;

  const item = room.currentItem;
  if (item) {
    $('#item-image').src = item.image || '';
    $('#item-name').textContent = item.name;
    $('#item-desc').textContent = item.description || '';
  }

  $('#auction-timer').textContent = formatTime(room.auctionTimer || 0);
  $('#current-bid').textContent = `₹${room.currentBid || 0}`;
  $('#highest-bidder').textContent = room.highestBidder || '—';

  if (room.lastBid) {
    $('#last-bid').textContent = `Last: ${room.lastBid.playerId} +₹${room.lastBid.amount}`;
  } else {
    $('#last-bid').textContent = 'Last: —';
  }

  updateMyPanel();

  // Auctioneer banner visibility
  if (['INTRO', 'GOING_ONCE', 'GOING_TWICE', 'SOLD'].includes(room.auctionState)) {
    // already handled by voice events
  } else if (room.auctionState === 'BIDDING') {
    $('#auctioneer-banner').classList.add('hidden');
  }
}

function updateMyPanel() {
  if (!currentRoom) return;
  const me = (currentRoom.players || []).find(p => p.id === myPlayerId);
  if (!me) return;

  $('#my-id').textContent = me.id;
  $('#my-balance').textContent = `₹${me.balance}`;
  $('#my-slots').textContent = `${me.slotsUsed} / ${currentRoom.maxSlots}`;

  const slotsFull = me.slotsUsed >= currentRoom.maxSlots;
  $('#slots-full').classList.toggle('hidden', !slotsFull);

  const canBid = currentRoom.status === 'AUCTION' &&
    ['BIDDING', 'GOING_ONCE', 'GOING_TWICE'].includes(currentRoom.auctionState) &&
    !slotsFull &&
    me.connected;

  $$('.bid-btn').forEach(btn => {
    const amount = Number(btn.dataset.amount);
    btn.disabled = !canBid || me.balance < amount;
  });
}

$$('.bid-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const amount = Number(btn.dataset.amount);
    if (!socket || !currentRoom) return;
    socket.emit('place_bid', { amount }, (res) => {
      if (res.error) toast(res.error);
    });
  });
});

// RESULTS
function showResults(room) {
  showScreen('result');
  const container = $('#result-cards');
  container.innerHTML = '';

  (room.results || []).forEach(r => {
    const card = document.createElement('div');
    card.className = 'result-card';
    card.innerHTML = `
      <h3>${r.id}</h3>
      <p>Items Won: <strong>${r.itemsWon}</strong></p>
      <p>Money Spent: <strong>₹${r.moneySpent}</strong></p>
      <p>Remaining: <strong>₹${r.remaining}</strong></p>
    `;
    container.appendChild(card);
  });

  $('#winner-name').textContent = room.winner || '—';
}

$('#btn-play-again').addEventListener('click', () => {
  currentRoom = null;
  showScreen('home');
});

$('#btn-home').addEventListener('click', () => {
  currentRoom = null;
  showScreen('home');
});

// Init
connectSocket();
showScreen('home');
